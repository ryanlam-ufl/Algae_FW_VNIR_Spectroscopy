import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
from scipy.signal import savgol_filter
from sklearn.cross_decomposition import PLSRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import KFold
from scipy.signal import detrend
from sklearn.svm import SVR
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor

data_path =  "./Lipids_062325.csv"

with open(data_path, 'r') as file:
    lines = file.readlines()    
# use pandas to read the csv file
df = pd.read_csv(data_path, skiprows=23, header=1)
reflectance = {}
cols = list(range(3, df.shape[1], 5))
for i, col in enumerate(cols):
    reflectance[i] = df.iloc[:, col].values
wavelengths = df.iloc[:, 0].values
print("Finished reading data from", data_path)

categories = {
    "baseline":  [*range(0, 3), *range(18, 21), *range(33, 36), *range(48, 51), *range(63, 66)],
    "2%_protein": [*range(0,15)],
    "5%_protein": [*range(15, 30),],
    "8%_protein": [*range(0, 15),],
    "10%_protein": [*range(15, 30),],
    }

protein2_5_path = "./Protein_2_5.csv"
with open(protein2_5_path, 'r') as file:
    lines = file.readlines()
df = pd.read_csv(protein2_5_path, skiprows=23, header=1)
reflectance_protein2_5 = {}
cols = list(range(3, df.shape[1], 5))
print(cols)
for i, col in enumerate(cols):
    reflectance_protein2_5[i] = df.iloc[:, col].values
wavelengths_protein2_5 = df.iloc[:, 0].values
print("Finished reading data from", protein2_5_path)

protein8_10_path = "./Protein_8_10.csv"
with open(protein8_10_path, 'r') as file:
    lines = file.readlines()
df = pd.read_csv(protein8_10_path, skiprows=23, header=1)
reflectance_protein8_10 = {}
cols = list(range(3, df.shape[1], 5))
print(cols)
for i, col in enumerate(cols):
    reflectance_protein8_10[i] = df.iloc[:, col].values
wavelengths_protein8_10 = df.iloc[:, 0].values
print("Finished reading data from", protein8_10_path)

import matplotlib.pyplot as plt

plt.figure(figsize=(12, 8))

# Plot mean of each category
mean_kwargs = dict(linewidth=3, linestyle='-')
# Baseline mean
baseline_vals = [reflectance[idx] for idx in categories["baseline"] if idx in reflectance]
if baseline_vals:
    plt.plot(wavelengths, np.mean(baseline_vals, axis=0), color='black', label="baseline mean", **mean_kwargs)
# 2% mean
protein2_vals = [reflectance_protein2_5[idx] for idx in categories["2%_protein"] if idx in reflectance_protein2_5]
if protein2_vals:
    plt.plot(wavelengths_protein2_5, np.mean(protein2_vals, axis=0), color='blue', label="2%_protein mean", **mean_kwargs)
# 5% mean
protein5_vals = [reflectance_protein2_5[idx] for idx in categories["5%_protein"] if idx in reflectance_protein2_5]
if protein5_vals:
    plt.plot(wavelengths_protein2_5, np.mean(protein5_vals, axis=0), color='red', label="5%_protein mean", **mean_kwargs)
# 8% mean
protein8_vals = [reflectance_protein8_10[idx] for idx in categories["8%_protein"] if idx in reflectance_protein8_10]
if protein8_vals:
    plt.plot(wavelengths_protein8_10, np.mean(protein8_vals, axis=0), color='green', label="8%_protein mean", **mean_kwargs)
# 10% mean
protein10_vals = [reflectance_protein8_10[idx] for idx in categories["10%_protein"] if idx in reflectance_protein8_10]
if protein10_vals:
    plt.plot(wavelengths_protein8_10, np.mean(protein10_vals, axis=0), color='orange', label="10%_protein mean", **mean_kwargs)

plt.xlabel("Wavelength (nm)")
plt.ylabel("Reflectance")
plt.title("Spectral Profiles of All Five Classes")
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))
plt.legend(by_label.values(), by_label.keys())
plt.tight_layout()
plt.show()

# Prepare data and labels
X = []
y = []
label_map = {
    "baseline": 44.8,
    "2%_protein": 45.90,
    "5%_protein": 47.56,
    "8%_protein": 49.22,
    "10%_protein": 50.32
}

def get_reflectance_arrays(category, reflectance_dict):
    return [reflectance_dict[idx] for idx in categories[category] if idx in reflectance_dict]

# Baseline
for arr in get_reflectance_arrays("baseline", reflectance):
    X.append(arr)
    y.append(label_map["baseline"])
# 2%_protein
for arr in get_reflectance_arrays("2%_protein", reflectance_protein2_5):
    X.append(arr)
    y.append(label_map["2%_protein"])
# 5%_protein
for arr in get_reflectance_arrays("5%_protein", reflectance_protein2_5):
    X.append(arr)
    y.append(label_map["5%_protein"])
# 8%_protein
for arr in get_reflectance_arrays("8%_protein", reflectance_protein8_10):
    X.append(arr)
    y.append(label_map["8%_protein"])
# 10%_protein
for arr in get_reflectance_arrays("10%_protein", reflectance_protein8_10):
    X.append(arr)
    y.append(label_map["10%_protein"])

X = np.array(X)
y = np.array(y, dtype=float)  # regression: float

# --- Preprocessing functions for HSI ---
def snv(X):
    """Standard Normal Variate (SNV)"""
    return (X - np.mean(X, axis=1, keepdims=True)) / np.std(X, axis=1, keepdims=True)

def msc(X):
    """Multiplicative Scatter Correction (MSC)"""
    mean_spectrum = np.mean(X, axis=0)
    X_msc = np.zeros_like(X)
    for i in range(X.shape[0]):
        fit = np.polyfit(mean_spectrum, X[i, :], 1, full=True)
        X_msc[i, :] = (X[i, :] - fit[0][1]) / fit[0][0]
    return X_msc

def savgol(X, window_length=11, polyorder=2, deriv=0):
    """Savitzky-Golay smoothing or derivative"""
    return savgol_filter(X, window_length=window_length, polyorder=polyorder, deriv=deriv, axis=1)

preprocessing_methods = ['none', 'log', 'snv', 'snv_detrend', 'msc', 'savgol', 'savgol_deriv']

for preprocessing_method in preprocessing_methods:
    print(f"\nUsing preprocessing method: {preprocessing_method}")
    X_train, X_test, y_train, y_test = [], [], [], []
    n_splits = 5

    for label in np.unique(y):
        idx = np.where(y == label)[0]
        X_cat = X[idx]
        y_cat = y[idx]
        kf = KFold(n_splits=n_splits, shuffle=False)
        # For demonstration, use the first fold (can loop for full CV)
        for fold_idx, (train_idx, test_idx) in enumerate(kf.split(X_cat)):
            if fold_idx == 0:
                X_train.append(X_cat[train_idx])
                X_test.append(X_cat[test_idx])
                y_train.append(y_cat[train_idx])
                y_test.append(y_cat[test_idx])
                break

    X_train = np.concatenate(X_train)
    X_test = np.concatenate(X_test)
    y_train = np.concatenate(y_train)
    y_test = np.concatenate(y_test)

    print("Training set shape:", X_train.shape, y_train.shape)
    print("Testing set shape:", X_test.shape, y_test.shape)

    # --- Choose preprocessing method ---
    # preprocessing_method = 'none'  # Options: 'none', 'snv', 'msc', 'savgol', 'savgol_deriv'
    if preprocessing_method != 'none':
        # Apply log(1/x) transformation to each data point
        X_train = np.log(1 / X_train)
        X_test = np.log(1 / X_test)
    else:
        X_train = X_train
        X_test = X_test

    if preprocessing_method == 'snv':
        X_train_prep = snv(X_train)
        X_test_prep = snv(X_test)
    elif preprocessing_method == 'snv_detrend':
        X_train_prep = detrend(snv(X_train), axis=1, type='linear')
        X_test_prep = detrend(snv(X_test), axis=1, type='linear')
    elif preprocessing_method == 'msc':
        X_train_prep = msc(X_train)
        X_test_prep = msc(X_test)
    elif preprocessing_method == 'savgol':
        X_train_prep = savgol(X_train, window_length=11, polyorder=2, deriv=0)
        X_test_prep = savgol(X_test, window_length=11, polyorder=2, deriv=0)
    elif preprocessing_method == 'savgol_deriv':
        X_train_prep = savgol(X_train, window_length=11, polyorder=2, deriv=1)
        X_test_prep = savgol(X_test, window_length=11, polyorder=2, deriv=1)
    else:
        X_train_prep = X_train
        X_test_prep = X_test

    output_dir = f"./5-fold/RF/protein/{preprocessing_method}"
    os.makedirs(output_dir, exist_ok=True)

    # Standardize features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_prep)
    X_test_scaled = scaler.transform(X_test_prep)

    param_grid = {
        'n_estimators': [50, 100, 200],
        'max_depth': [None, 5, 10, 20],
        'min_samples_split': [2, 5, 10],
    }
    rf_model = RandomForestRegressor(random_state=42)
    grid_search = GridSearchCV(rf_model, param_grid, cv=5, scoring='neg_root_mean_squared_error', n_jobs=-1)
    grid_search.fit(X_train_scaled, y_train)
    print("Best RF parameters:", grid_search.best_params_)

    # Save best parameters to a txt file
    best_params_path = os.path.join(output_dir, "best_rf_params.txt")
    with open(best_params_path, "w") as f:
        f.write(str(grid_search.best_params_))
    print(f"Best RF parameters saved to {best_params_path}")

    # Use the best estimator for prediction
    rf = grid_search.best_estimator_

    rf.fit(X_train_scaled, y_train)
    y_pred_reg = rf.predict(X_test_scaled).ravel()


    print("RF Results:")
    print("y_test (true concentrations):", y_test)
    print("y_pred (predicted concentrations):", y_pred_reg)

    # Print RMSE and R2
    print("Test RMSE: {:.3f}".format(np.sqrt(mean_squared_error(y_test, y_pred_reg))))
    print("Test R2: {:.3f}".format(r2_score(y_test, y_pred_reg)))

    # Plot predictions vs ground truth
    plt.figure(figsize=(8, 8))
    plt.scatter(y_test, y_pred_reg, color='blue', label='testing data')

    # Add fitted curve
    z = np.polyfit(y_test, y_pred_reg, 1)
    p = np.poly1d(z)
    plt.plot(y_test, p(y_test), "r--", alpha=0.8, label=f'Fitted line (y={z[0]:.3f}x{z[1]:.3f})')

    r2 = r2_score(y_test, y_pred_reg)
    plt.text(
        0.95, 0.05,
        f'$R^2$ = {r2:.3f}\nRMSE = {np.sqrt(mean_squared_error(y_test, y_pred_reg)):.3f}',
        transform=plt.gca().transAxes,
        fontsize=12,
        verticalalignment='bottom',
        horizontalalignment='right',
        bbox=dict(boxstyle='round', facecolor='white', alpha=0.7)
    )
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=2, label='1:1 line')
    plt.xlabel('Actual Protein Concentration (%)')
    plt.ylabel('Predicted Protein Concentration (%)')
    plt.title('RF result')
    plt.legend()
    plt.tight_layout()
    plt.show()

    fold_datasets = []
    kf = KFold(n_splits=5, shuffle=False)
    labels = np.unique(y)

    # For each fold, collect train/test indices for all labels
    for fold_idx in range(5):
        X_train_fold, X_test_fold, y_train_fold, y_test_fold = [], [], [], []
        for label in labels:
            idx = np.where(y == label)[0]
            X_cat = X[idx]
            y_cat = y[idx]
            kf_label = KFold(n_splits=5, shuffle=False)
            for i, (train_idx, test_idx) in enumerate(kf_label.split(X_cat)):
                if i == fold_idx:
                    X_train_fold.append(X_cat[train_idx])
                    X_test_fold.append(X_cat[test_idx])
                    y_train_fold.append(y_cat[train_idx])
                    y_test_fold.append(y_cat[test_idx])
                    break
        X_train_fold = np.concatenate(X_train_fold)
        X_test_fold = np.concatenate(X_test_fold)
        y_train_fold = np.concatenate(y_train_fold)
        y_test_fold = np.concatenate(y_test_fold)
        fold_datasets.append((X_train_fold, X_test_fold, y_train_fold, y_test_fold))

    # For each dataset, build model, predict, and save plot
    rmse_list = []
    r2_list = []
    rpd_list = []
    train_rmse_list = []
    train_r2_list = []
    train_rpd_list = []   

    for fold_idx, (X_train_fold, X_test_fold, y_train_fold, y_test_fold) in enumerate(fold_datasets):
        if preprocessing_method != 'none':
            # Apply log(1/x) transformation to each data point
            X_train_fold = np.log(1 / X_train_fold)
            X_test_fold = np.log(1 / X_test_fold)
        else:
            X_train_fold = X_train_fold
            X_test_fold = X_test_fold

        if preprocessing_method == 'snv':
            X_train_prep = snv(X_train_fold)
            X_test_prep = snv(X_test_fold)
        elif preprocessing_method == 'snv_detrend':
            X_train_prep = detrend(snv(X_train_fold), axis=1, type='linear')
            X_test_prep = detrend(snv(X_test_fold), axis=1, type='linear')
        elif preprocessing_method == 'msc':
            X_train_prep = msc(X_train_fold)
            X_test_prep = msc(X_test_fold)
        elif preprocessing_method == 'savgol':
            X_train_prep = savgol(X_train_fold, window_length=11, polyorder=2, deriv=0)
            X_test_prep = savgol(X_test_fold, window_length=11, polyorder=2, deriv=0)
        elif preprocessing_method == 'savgol_deriv':
            X_train_prep = savgol(X_train_fold, window_length=11, polyorder=2, deriv=1)
            X_test_prep = savgol(X_test_fold, window_length=11, polyorder=2, deriv=1)
        else:
            X_train_prep = X_train_fold
            X_test_prep = X_test_fold

        scaler_fold = StandardScaler()
        X_train_scaled = scaler_fold.fit_transform(X_train_prep)
        X_test_scaled = scaler_fold.transform(X_test_prep)

        rf_fold = RandomForestRegressor(
            n_estimators=grid_search.best_params_['n_estimators'],
            max_depth=grid_search.best_params_['max_depth'],
            min_samples_split=grid_search.best_params_['min_samples_split'],
            random_state=42
        )
        rf_fold.fit(X_train_scaled, y_train_fold)

        # Evaluate on training set for this fold
        y_pred_train_fold = rf_fold.predict(X_train_scaled).ravel()
        rmse_train = np.sqrt(mean_squared_error(y_train_fold, y_pred_train_fold))
        r2_train = r2_score(y_train_fold, y_pred_train_fold)
        std_train = np.std(y_train_fold)
        rpd_train = std_train / rmse_train if rmse_train != 0 else np.nan
        train_rmse_list.append(rmse_train)
        train_r2_list.append(r2_train)
        train_rpd_list.append(rpd_train)
        print(f" Fold {fold_idx+1}: Train RMSE = {rmse_train:.4f}, R2 = {r2_train:.4f}, RPD = {rpd_train:.4f}")

        y_pred_fold = rf_fold.predict(X_test_scaled).ravel()

        # Calculate RMSE and R2 for this fold
        rmse = np.sqrt(mean_squared_error(y_test_fold, y_pred_fold))
        r2 = r2_score(y_test_fold, y_pred_fold)
        std = np.std(y_test_fold)
        rpd = std / rmse if rmse != 0 else np.nan
        rmse_list.append(rmse)
        r2_list.append(r2)
        rpd_list.append(rpd)
        print(f" Fold {fold_idx+1}: Test RMSE = {rmse:.4f}, R2 = {r2:.4f}, RPD = {rpd:.4f}")

        # Plotting results for this fold
        plt.figure(figsize=(8, 8))
        plt.scatter(y_test_fold, y_pred_fold, color='blue', label=f'Fold {fold_idx+1} predictions')
        z = np.polyfit(y_test_fold, y_pred_fold, 1)
        p = np.poly1d(z)
        sign = '+' if z[1] >= 0 else ''
        plt.plot(y_test_fold, p(y_test_fold), "r--", alpha=0.8, label=f'Fitted line (y={z[0]:.3f}x{sign}{z[1]:.3f})')
        r2_cv = r2_score(y_test_fold, y_pred_fold)
        plt.text(
            0.95, 0.05,
            f'$R^2$ = {r2_cv:.3f}\nRMSE = {rmse:.3f}',
            transform=plt.gca().transAxes,
            fontsize=12,
            verticalalignment='bottom',
            horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.7)
        )
        plt.plot([y_test_fold.min(), y_test_fold.max()], [y_test_fold.min(), y_test_fold.max()], 'k--', lw=2, label='1:1 line')
        plt.xlabel('Actual protein Concentration (%)')
        plt.ylabel('Predicted protein Concentration (%)')
        plt.title(f'RF 5-fold Cross-Validation Fold {fold_idx+1}')
        plt.legend()
        plt.tight_layout()
        plot_path = os.path.join(output_dir, f"rf_5fold_cv_results_fold{fold_idx+1}.png")
        plt.savefig(plot_path, dpi=300)
        plt.close()

    print("\nAverage training RMSE over 5 folds: {:.4f}".format(np.mean(train_rmse_list)))
    print("Average training R2 over 5 folds: {:.4f}".format(np.mean(train_r2_list)))
    print("Average training RPD over 5 folds: {:.4f}".format(np.mean(train_rpd_list)))
    print("Std of training RMSE over 5 folds: {:.4f}".format(np.std(train_rmse_list)))
    print("Std of training R2 over 5 folds: {:.4f}".format(np.std(train_r2_list)))
    print("Std of training RPD over 5 folds: {:.4f}".format(np.std(train_rpd_list)))
    print(f"\nAverage RMSE over 5 folds: {np.mean(rmse_list):.4f}")
    print(f"Average R2 over 5 folds: {np.mean(r2_list):.4f}")
    print(f"Average RPD over 5 folds: {np.mean(rpd_list):.4f}")
    print(f"Std of RMSE over 5 folds: {np.std(rmse_list):.4f}")
    print(f"Std of R2 over 5 folds: {np.std(r2_list):.4f}")
    print(f"Std of RPD over 5 folds: {np.std(rpd_list):.4f}")
    # Save overall results to a txt file
    results_path = os.path.join(output_dir, "rf_5fold_cv_results.txt")
    with open(results_path, "w") as f:
        f.write(f"Average training RMSE over 5 folds: {np.mean(train_rmse_list):.4f}\n")
        f.write(f"Average training R2 over 5 folds: {np.mean(train_r2_list):.4f}\n")
        f.write(f"Average training RPD over 5 folds: {np.mean(train_rpd_list):.4f}\n")
        f.write(f"Std of training RMSE over 5 folds: {np.std(train_rmse_list):.4f}\n")
        f.write(f"Std of training R2 over 5 folds: {np.std(train_r2_list):.4f}\n")
        f.write(f"Std of training RPD over 5 folds: {np.std(train_rpd_list):.4f}\n\n")
        f.write(f"Average RMSE over 5 folds: {np.mean(rmse_list):.4f}\n")
        f.write(f"Average R2 over 5 folds: {np.mean(r2_list):.4f}\n")
        f.write(f"Average RPD over 5 folds: {np.mean(rpd_list):.4f}\n")
        f.write(f"Std of RMSE over 5 folds: {np.std(rmse_list):.4f}\n")
        f.write(f"Std of R2 over 5 folds: {np.std(r2_list):.4f}\n")
        f.write(f"Std of RPD over 5 folds: {np.std(rpd_list):.4f}\n")
