import os
import pandas as pd
import numpy as np
import json
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
from scipy.signal import savgol_filter
from sklearn.cross_decomposition import PLSRegression
#from sklearn.preprocessing import LabelBinarizer
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.svm import SVR
from sklearn.model_selection import KFold
from scipy.signal import detrend
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor
import torch
from torch.utils.data import TensorDataset, DataLoader
import optuna

data_path = "./Food_Waste.csv"

with open(data_path, 'r') as file:
    lines = file.readlines()    
# use pandas to read the csv file
df = pd.read_csv(data_path, skiprows=23, header=1)
reflectance = {}
cols = list(range(3, df.shape[1], 5))
for i, col in enumerate(cols):
    reflectance[i] = df.iloc[:, col].values
wavelengths = df.iloc[:, 0].values
print("Finished reading data from", data_path)


categories = {
    "baseline":  [*range(0, 15)],
    "2%_carb": [*range(75, 90)],
    "5%_carb": [*range(90, 105)],
    "8%_carb": [*range(105, 120)],
    "10%_carb": [*range(120, 135)],
}

reflectance_carb2_5 = {}
cols = list(range(3, df.shape[1], 5))
print(cols)
for i, col in enumerate(cols):
    reflectance_carb2_5[i] = df.iloc[:, col].values
wavelengths_carb2_5 = df.iloc[:, 0].values

reflectance_carb8_10 = {}
cols = list(range(3, df.shape[1], 5))
print(cols)
for i, col in enumerate(cols):
    reflectance_carb8_10[i] = df.iloc[:, col].values
wavelengths_carb8_10 = df.iloc[:, 0].values

import matplotlib.pyplot as plt

plt.figure(figsize=(12, 8))

# Plot mean of each category
mean_kwargs = dict(linewidth=3, linestyle='-')
# Baseline mean
baseline_vals = [reflectance[idx] for idx in categories["baseline"] if idx in reflectance]
if baseline_vals:
    plt.plot(wavelengths, np.mean(baseline_vals, axis=0), color='black', label="baseline mean", **mean_kwargs)
# 2% mean
carb2_vals = [reflectance_carb2_5[idx] for idx in categories["2%_carb"] if idx in reflectance_carb2_5]
if carb2_vals:
    plt.plot(wavelengths_carb2_5, np.mean(carb2_vals, axis=0), color='blue', label="2%_carb mean", **mean_kwargs)
# 5% mean
carb5_vals = [reflectance_carb2_5[idx] for idx in categories["5%_carb"] if idx in reflectance_carb2_5]
if carb5_vals:
    plt.plot(wavelengths_carb2_5, np.mean(carb5_vals, axis=0), color='red', label="5%_carb mean", **mean_kwargs)
# 8% mean
carb8_vals = [reflectance_carb8_10[idx] for idx in categories["8%_carb"] if idx in reflectance_carb8_10]
if carb8_vals:
    plt.plot(wavelengths_carb8_10, np.mean(carb8_vals, axis=0), color='green', label="8%_carb mean", **mean_kwargs)
# 10% mean
carb10_vals = [reflectance_carb8_10[idx] for idx in categories["10%_carb"] if idx in reflectance_carb8_10]
if carb10_vals:
    plt.plot(wavelengths_carb8_10, np.mean(carb10_vals, axis=0), color='orange', label="10%_carb mean", **mean_kwargs)

plt.xlabel("Wavelength (nm)")
plt.ylabel("Reflectance")
plt.title("Spectral Profiles of All Five Classes")
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))
plt.legend(by_label.values(), by_label.keys())
plt.tight_layout()
plt.show()

# Prepare data and labels for regression
X = []
y = []
label_map = {
    "baseline": 43.70,
    "2%_carb": 44.83,
    "5%_carb": 46.52,
    "8%_carb": 48.20,
    "10%_carb": 49.33
}

def get_reflectance_arrays(category, reflectance_dict):
    return [reflectance_dict[idx] for idx in categories[category] if idx in reflectance_dict]

# Baseline
for arr in get_reflectance_arrays("baseline", reflectance):
    X.append(arr)
    y.append(label_map["baseline"])
# 2%_carb
for arr in get_reflectance_arrays("2%_carb", reflectance_carb2_5):
    X.append(arr)
    y.append(label_map["2%_carb"])
# 5%_carb
for arr in get_reflectance_arrays("5%_carb", reflectance_carb2_5):
    X.append(arr)
    y.append(label_map["5%_carb"])
# 8%_carb
for arr in get_reflectance_arrays("8%_carb", reflectance_carb8_10):
    X.append(arr)
    y.append(label_map["8%_carb"])
# 10%_carb
for arr in get_reflectance_arrays("10%_carb", reflectance_carb8_10):
    X.append(arr)
    y.append(label_map["10%_carb"])

X = np.array(X)
y = np.array(y, dtype=float)  # regression: float

# --- Preprocessing functions for HSI ---
def snv(X):
    """Standard Normal Variate (SNV)"""
    return (X - np.mean(X, axis=1, keepdims=True)) / np.std(X, axis=1, keepdims=True)

def msc(X):
    """Multiplicative Scatter Correction (MSC)"""
    mean_spectrum = np.mean(X, axis=0)
    X_msc = np.zeros_like(X)
    for i in range(X.shape[0]):
        fit = np.polyfit(mean_spectrum, X[i, :], 1, full=True)
        X_msc[i, :] = (X[i, :] - fit[0][1]) / fit[0][0]
    return X_msc

def savgol(X, window_length=11, polyorder=2, deriv=0):
    """Savitzky-Golay smoothing or derivative"""
    return savgol_filter(X, window_length=window_length, polyorder=polyorder, deriv=deriv, axis=1)

preprocessing_methods = ['none', 'log', 'snv', 'snv_detrend', 'msc', 'savgol', 'savgol_deriv']

for preprocessing_method in preprocessing_methods:
    print(f"\nUsing preprocessing method: {preprocessing_method}")

    X_train, X_test, y_train, y_test = [], [], [], []
    n_splits = 5

    for label in np.unique(y):
        idx = np.where(y == label)[0]
        X_cat = X[idx]
        y_cat = y[idx]
        kf = KFold(n_splits=n_splits, shuffle=False)
        # For demonstration, use the first fold (can loop for full CV)
        for fold_idx, (train_idx, test_idx) in enumerate(kf.split(X_cat)):
            if fold_idx == 0:
                X_train.append(X_cat[train_idx])
                X_test.append(X_cat[test_idx])
                y_train.append(y_cat[train_idx])
                y_test.append(y_cat[test_idx])
                break

    X_train = np.concatenate(X_train)
    X_test = np.concatenate(X_test)
    y_train = np.concatenate(y_train)
    y_test = np.concatenate(y_test)

    print("Training set shape:", X_train.shape, y_train.shape)
    print("Testing set shape:", X_test.shape, y_test.shape)

    # # --- Choose preprocessing method ---
    # preprocessing_method = 'savgol_deriv'  # Options: 'none', 'snv', 'msc', 'savgol', 'savgol_deriv'
    if preprocessing_method != 'none':
        # Apply log(1/x) transformation to each data point
        X_train = np.log(1 / X_train)
        X_test = np.log(1 / X_test)
    else:
        X_train = X_train
        X_test = X_test

    if preprocessing_method == 'snv':
        X_train_prep = snv(X_train)
        X_test_prep = snv(X_test)
    elif preprocessing_method == 'snv_detrend':
        X_train_prep = detrend(snv(X_train), axis=1, type='linear')
        X_test_prep = detrend(snv(X_test), axis=1, type='linear')
    elif preprocessing_method == 'msc':
        X_train_prep = msc(X_train)
        X_test_prep = msc(X_test)
    elif preprocessing_method == 'savgol':
        X_train_prep = savgol(X_train, window_length=11, polyorder=2, deriv=0)
        X_test_prep = savgol(X_test, window_length=11, polyorder=2, deriv=0)
    elif preprocessing_method == 'savgol_deriv':
        X_train_prep = savgol(X_train, window_length=11, polyorder=2, deriv=1)
        X_test_prep = savgol(X_test, window_length=11, polyorder=2, deriv=1)
    else:
        X_train_prep = X_train
        X_test_prep = X_test

    output_dir = f"./5fold/CNN_opti/carb/{preprocessing_method}"
    os.makedirs(output_dir, exist_ok=True)

    # Standardize features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_prep)
    X_test_scaled = scaler.transform(X_test_prep)

    import torch.nn as nn
    import torch.optim as optim

    class CNN1DRegressor(nn.Module):
        def __init__(self, input_length, n_filters1=8, n_filters2=16, kernel_size=5, hidden_dim=16, dropout=0.0):
            super().__init__()
            self.conv1 = nn.Conv1d(1, n_filters1, kernel_size=kernel_size, padding=kernel_size // 2)
            self.relu1 = nn.ReLU()
            self.conv2 = nn.Conv1d(n_filters1, n_filters2, kernel_size=kernel_size, padding=kernel_size // 2)
            self.relu2 = nn.ReLU()
            self.dropout = nn.Dropout(dropout)
            self.flatten = nn.Flatten()
            self.fc1 = nn.Linear(n_filters2 * input_length, hidden_dim)
            self.relu3 = nn.ReLU()
            self.fc2 = nn.Linear(hidden_dim, 1)

        def forward(self, x):
            x = self.conv1(x)
            x = self.relu1(x)
            x = self.conv2(x)
            x = self.relu2(x)
            x = self.dropout(x)
            x = self.flatten(x)
            x = self.fc1(x)
            x = self.relu3(x)
            x = self.fc2(x)
            return x.squeeze(-1)


    def train_and_evaluate(model, train_loader, X_val, y_val, device, lr, reg_coeff, epochs=100):
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=reg_coeff)

        for epoch in range(epochs):
            model.train()
            for X_batch, y_batch in train_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                optimizer.zero_grad()
                loss = criterion(model(X_batch), y_batch)
                loss.backward()
                optimizer.step()

        model.eval()
        with torch.no_grad():
            y_pred = model(X_val.to(device)).cpu().numpy()
        rmse = np.sqrt(mean_squared_error(y_val, y_pred))
        r2 = r2_score(y_val, y_pred)
        return rmse, r2


    def objective(trial):
        n_filters1 = trial.suggest_categorical("n_filters1", [8, 16, 32, 64])
        n_filters2 = trial.suggest_categorical("n_filters2", [16, 32, 64, 128])
        kernel_size = trial.suggest_categorical("kernel_size", [3, 5, 7])
        hidden_dim = trial.suggest_categorical("hidden_dim", [16, 32, 64, 128])
        dropout = trial.suggest_float("dropout", 0.0, 0.5)
        lr = trial.suggest_float("lr", 1e-4, 1e-2, log=True)
        reg_coeff = trial.suggest_float("reg_coeff", 1e-6, 1e-2, log=True)
        batch_size = trial.suggest_categorical("batch_size", [16, 32, 64, 128])

        train_dataset = TensorDataset(X_train_torch, y_train_torch)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

        model = CNN1DRegressor(
            input_length=input_length,
            n_filters1=n_filters1,
            n_filters2=n_filters2,
            kernel_size=kernel_size,
            hidden_dim=hidden_dim,
            dropout=dropout
        ).to(device)

        rmse, r2 = train_and_evaluate(model, train_loader, X_test_torch, y_test_torch, device, lr, reg_coeff)
        trial.set_user_attr("r2", r2)
        return rmse


    # Prepare data for PyTorch
    X_train_torch = torch.tensor(X_train_scaled, dtype=torch.float32).unsqueeze(1)  # (N, 1, L)
    y_train_torch = torch.tensor(y_train, dtype=torch.float32)
    X_test_torch = torch.tensor(X_test_scaled, dtype=torch.float32).unsqueeze(1)
    y_test_torch = torch.tensor(y_test, dtype=torch.float32)

    input_length = X_train_scaled.shape[1]
    # model = CNN1DRegressor(input_length)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    study = optuna.create_study(direction="minimize")
    study.optimize(objective, n_trials=30, timeout=3600)

    best_trial = study.best_trial
    print("\nBest trial:")
    print(f"  RMSE: {best_trial.value:.4f}")
    print(f"  R2: {best_trial.user_attrs['r2']:.4f}")
    print("  Params:", best_trial.params)

    # Save best parameters
    with open(f"{output_dir}/best_cnn1d_params.json", "w") as f:
        json.dump(best_trial.params, f, indent=4)
    print("Best parameters saved to best_cnn1d_params.json")

    with open(f"{output_dir}/best_cnn1d_params.json", "r") as f:
        best_params = json.load(f)
    print("\nLoaded best parameters:", best_params)

    kf = KFold(n_splits=5, shuffle=False)
    # Prepare 5 datasets, each with a different fold for each label as test set
    fold_datasets = []
    kf = KFold(n_splits=5, shuffle=False)
    labels = np.unique(y)

    # For each fold, collect train/test indices for all labels
    for fold_idx in range(5):
        X_train_fold, X_test_fold, y_train_fold, y_test_fold = [], [], [], []
        for label in labels:
            idx = np.where(y == label)[0]
            X_cat = X[idx]
            y_cat = y[idx]
            kf_label = KFold(n_splits=5, shuffle=False)
            for i, (train_idx, test_idx) in enumerate(kf_label.split(X_cat)):
                if i == fold_idx:
                    X_train_fold.append(X_cat[train_idx])
                    X_test_fold.append(X_cat[test_idx])
                    y_train_fold.append(y_cat[train_idx])
                    y_test_fold.append(y_cat[test_idx])
                    break
        X_train_fold = np.concatenate(X_train_fold)
        X_test_fold = np.concatenate(X_test_fold)
        y_train_fold = np.concatenate(y_train_fold)
        y_test_fold = np.concatenate(y_test_fold)
        fold_datasets.append((X_train_fold, X_test_fold, y_train_fold, y_test_fold))

    # For each dataset, build model, predict, and save plot
    rmse_list = []
    r2_list = []
    rpd_list = []
    train_rmse_list = []
    train_r2_list = []
    train_rpd_list = []

    for fold_idx, (X_train_fold, X_test_fold, y_train_fold, y_test_fold) in enumerate(fold_datasets):
        # Preprocessing
        if preprocessing_method != 'none':
            # Apply log(1/x) transformation to each data point
            X_train_fold = np.log(1 / X_train_fold)
            X_test_fold = np.log(1 / X_test_fold)
        else:
            X_train_fold = X_train_fold
            X_test_fold = X_test_fold

        if preprocessing_method == 'snv':
            X_train_prep = snv(X_train_fold)
            X_test_prep = snv(X_test_fold)
        elif preprocessing_method == 'snv_detrend':
            X_train_prep = detrend(snv(X_train_fold), axis=1, type='linear')
            X_test_prep = detrend(snv(X_test_fold), axis=1, type='linear')
        elif preprocessing_method == 'msc':
            X_train_prep = msc(X_train_fold)
            X_test_prep = msc(X_test_fold)
        elif preprocessing_method == 'savgol':
            X_train_prep = savgol(X_train_fold, window_length=11, polyorder=2, deriv=0)
            X_test_prep = savgol(X_test_fold, window_length=11, polyorder=2, deriv=0)
        elif preprocessing_method == 'savgol_deriv':
            X_train_prep = savgol(X_train_fold, window_length=11, polyorder=2, deriv=1)
            X_test_prep = savgol(X_test_fold, window_length=11, polyorder=2, deriv=1)
        else:
            X_train_prep = X_train_fold
            X_test_prep = X_test_fold
        scaler_fold = StandardScaler()
        X_train_scaled = scaler_fold.fit_transform(X_train_prep)
        X_test_scaled = scaler_fold.transform(X_test_prep)

        # Prepare data for PyTorch
        X_train_torch = torch.tensor(X_train_scaled, dtype=torch.float32).unsqueeze(1)  # (N, 1, L)
        y_train_torch = torch.tensor(y_train_fold, dtype=torch.float32)
        X_test_torch = torch.tensor(X_test_scaled, dtype=torch.float32).unsqueeze(1)
        y_test_torch = torch.tensor(y_test_fold, dtype=torch.float32)

        with open(f"{output_dir}/best_cnn1d_params.json", "r") as f:
            best_params = json.load(f)
        print("\nLoaded best parameters:", best_params)

        # Create DataLoader with batch size 32 and shuffle
        batch_size = best_params["batch_size"]
        train_dataset = TensorDataset(X_train_torch, y_train_torch)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

        input_length = X_train_scaled.shape[1]

        model = CNN1DRegressor(
            input_length=input_length,
            n_filters1=best_params["n_filters1"],
            n_filters2=best_params["n_filters2"],
            kernel_size=best_params["kernel_size"],
            hidden_dim=best_params["hidden_dim"],
            dropout=best_params["dropout"]
        )

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = model.to(device)
        X_test_torch = X_test_torch.to(device)
        y_test_torch = y_test_torch.to(device)

        # Loss and optimizer
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=best_params["lr"], weight_decay=best_params["reg_coeff"])

        # Training loop with DataLoader
        epochs = 200
        for epoch in range(epochs):
            model.train()
            epoch_loss = 0.0
            for X_batch, y_batch in train_loader:
                X_batch = X_batch.to(device)
                y_batch = y_batch.to(device)
                optimizer.zero_grad()
                outputs = model(X_batch)
                loss = criterion(outputs, y_batch)
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item() * X_batch.size(0)
            epoch_loss /= len(train_loader.dataset)
            if (epoch + 1) % 10 == 0 or epoch == 0:
                print(f"Epoch {epoch + 1}/{epochs}, Loss: {epoch_loss:.4f}")

        # Save the last model weights
        torch.save(model.state_dict(), f"{output_dir}/carb_cnn1d_regressor_Fold {fold_idx+1}_last.pth")

        # Evaluation

        model.eval()
        with torch.no_grad():
            y_train_pred = model(X_train_torch.to(device)).cpu().numpy()
        train_rmse = np.sqrt(mean_squared_error(y_train_fold, y_train_pred))
        train_r2 = r2_score(y_train_fold, y_train_pred)
        std_train = np.std(y_train_fold)
        train_rpd = std_train / train_rmse if train_rmse != 0 else np.nan
        train_rmse_list.append(train_rmse)
        train_r2_list.append(train_r2)
        train_rpd_list.append(train_rpd)
        print(f"Fold {fold_idx+1}: Training RMSE = {train_rmse:.4f}, R2 = {train_r2:.4f}, RPD = {train_rpd:.4f}")

        model.eval()
        with torch.no_grad():
            y_pred_cnn = model(X_test_torch.to(device)).cpu().numpy()


        # Calculate RMSE and R2 for this fold
        rmse = np.sqrt(mean_squared_error(y_test_fold, y_pred_cnn))
        r2 = r2_score(y_test_fold, y_pred_cnn)
        std_test = np.std(y_test_fold)
        rpd = std_test / rmse if rmse != 0 else np.nan        
        rmse_list.append(rmse)
        r2_list.append(r2)
        rpd_list.append(rpd)
        print(f"Fold {fold_idx+1}: Test RMSE = {rmse:.4f}, R2 = {r2:.4f}, RPD = {rpd:.4f}")

        # Plotting results for this fold
        plt.figure(figsize=(8, 8))
        plt.scatter(y_test_fold, y_pred_cnn, color='blue', label=f'Fold {fold_idx+1} predictions')
        z = np.polyfit(y_test_fold, y_pred_cnn, 1)
        p = np.poly1d(z)
        sign = '+' if z[1] >= 0 else ''
        plt.plot(y_test_fold, p(y_test_fold), "r--", alpha=0.8, label=f'Fitted line (y={z[0]:.3f}x{sign}{z[1]:.3f})')
        r2_cv = r2_score(y_test_fold, y_pred_cnn)
        plt.text(
            0.95, 0.05,
            f'$R^2$ = {r2_cv:.3f}\nRMSE = {rmse:.3f}',
            transform=plt.gca().transAxes,
            fontsize=12,
            verticalalignment='bottom',
            horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.7)
        )
        plt.plot([y_test_fold.min(), y_test_fold.max()], [y_test_fold.min(), y_test_fold.max()], 'k--', lw=2, label='1:1 line')
        plt.xlabel('Actual Carbohydrate Concentration (%)')
        plt.ylabel('Predicted Carbohydrate Concentration (%)')
        plt.title(f'cnn 5-fold Cross-Validation Fold {fold_idx+1}')
        plt.legend()
        plt.tight_layout()
        plot_path = os.path.join(output_dir, f"cnn_5fold_cv_results_fold{fold_idx+1}.png")
        plt.savefig(plot_path, dpi=300)
        plt.close()

    print("\nAverage training RMSE over 5 folds: {:.4f}".format(np.mean(train_rmse_list)))
    print("Average training R2 over 5 folds: {:.4f}".format(np.mean(train_r2_list)))
    print("Average training RPD over 5 folds: {:.4f}".format(np.mean(train_rpd_list)))
    print("Std of training RMSE over 5 folds: {:.4f}".format(np.std(train_rmse_list)))
    print("Std of training R2 over 5 folds: {:.4f}".format(np.std(train_r2_list)))
    print("Std of training RPD over 5 folds: {:.4f}".format(np.std(train_rpd_list)))
    print(f"\nAverage RMSE over 5 folds: {np.mean(rmse_list):.4f}")
    print(f"Average R2 over 5 folds: {np.mean(r2_list):.4f}")
    print(f"Average RPD over 5 folds: {np.mean(rpd_list):.4f}")
    print(f"Std of RMSE over 5 folds: {np.std(rmse_list):.4f}")
    print(f"Std of R2 over 5 folds: {np.std(r2_list):.4f}")
    print(f"Std of RPD over 5 folds: {np.std(rpd_list):.4f}")
    # Save overall results to a txt file
    results_path = os.path.join(output_dir, "cnn_5fold_cv_results.txt")
    with open(results_path, "w") as f:
        f.write(f"Average training RMSE over 5 folds: {np.mean(train_rmse_list):.4f}\n")
        f.write(f"Average training R2 over 5 folds: {np.mean(train_r2_list):.4f}\n")
        f.write(f"Average training RPD over 5 folds: {np.mean(train_rpd_list):.4f}\n")
        f.write(f"Std of training RMSE over 5 folds: {np.std(train_rmse_list):.4f}\n")
        f.write(f"Std of training R2 over 5 folds: {np.std(train_r2_list):.4f}\n")
        f.write(f"Std of training RPD over 5 folds: {np.std(train_rpd_list):.4f}\n\n")
        f.write(f"Average RMSE over 5 folds: {np.mean(rmse_list):.4f}\n")
        f.write(f"Average R2 over 5 folds: {np.mean(r2_list):.4f}\n")
        f.write(f"Average RPD over 5 folds: {np.mean(rpd_list):.4f}\n")
        f.write(f"Std of RMSE over 5 folds: {np.std(rmse_list):.4f}\n")
        f.write(f"Std of R2 over 5 folds: {np.std(r2_list):.4f}\n")
        f.write(f"Std of RPD over 5 folds: {np.std(rpd_list):.4f}\n")
